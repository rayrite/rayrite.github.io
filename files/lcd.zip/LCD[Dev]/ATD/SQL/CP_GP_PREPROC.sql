SET SERVEROUT ON SIZE 999999
	
CREATE OR REPLACE PROCEDURE
      LCD.CP_GP_PREPROC (p_User 		IN  VARCHAR2,
            		 p_Org		IN  VARCHAR2,
            		 p_InFileName	IN  VARCHAR2,
            		 p_WeekEnding	IN  VARCHAR2,
           			 p_FileNameWage	IN  VARCHAR2,
           			 p_FileNameTime	IN  VARCHAR2)
IS

-- ***********************************************************************
-- CostPoint Gross Pay Preprocessor
-- ***********************************************************************
--
-- 		M O D I F I C A T I O N   H I S T O R Y
--
--    22 Sep 2006 efadul    created
--    06 Nov 2006 efadul    modified code such that p_WeekEnding may fall
--    			    on any day of the week.  First day of the week
--				    is based on the week_ending date
--    08 Nov 2006 efadul    Changed Write_Wage_File. Appended the WeekEndingDate 
--				    to the generated wage file in MM/DD/YYYY format; 
--				    Changed ReadRecord.  Allowed a lower case 'P' to 
--				    be accepted as a negative number indicator. 
--				    SR(150239-00035)
--    01 Jan 2006 efadul    added code to list the missing employees
-- ***********************************************************************

lFileHandleIn     UTL_FILE.FILE_TYPE;
lFileHandleTime   UTL_FILE.FILE_TYPE;
lFileHandleWage   UTL_FILE.FILE_TYPE;
l_InCount		INTEGER := 0;
l_TimeCount		INTEGER := 0;
l_WageCount		INTEGER := 0;
l_DispCount		INTEGER := 0;

l_WeekEndingDate  DATE;

l_bError		BOOLEAN := FALSE;
l_bValidationErr	BOOLEAN := FALSE;

l_PreProcName     VARCHAR2(20) := 'CP_GP_PREPROC';
l_dir_name_IN 	LCD.ORG_PARAM.LCD_SERVER_LOC%TYPE;
l_dir_name_OUT	LCD.ORG_PARAM.LCD_SERVER_LOC%TYPE;
l_linefeed		CHAR(1) := Chr(10);
l_ErrMsg          VARCHAR2(250);
l_TimeType		VARCHAR(4);
l_WageType		VARCHAR(4);
l_IllegalTimeType VARCHAR2(500);
l_MissingWorkers  VARCHAR2(330);
l_IllegalWageType VARCHAR2(500);
l_WrkrMissing     INTEGER := 0;
l_commaT		VARCHAR2(2) := NULL;
l_commaW		VARCHAR2(2) := NULL;
l_commaM		VARCHAR2(2) := NULL;
l_EMPL_curr		VARCHAR2(9);
l_SSN_curr        VARCHAR2(10);
l_TotHours		NUMBER := 0;
l_TotLabCost	NUMBER := 0;
l_WorkerType 	VARCHAR2(4);
EventLogError     EXCEPTION;

sStatus 		LCD.JOB_TABLE.JOB_STATUS%TYPE;
sComments 		VARCHAR2(1000); -- LCD.JOB_TABLE.COMMENTS%TYPE;

TYPE wk IS TABLE OF DATE INDEX BY BINARY_INTEGER;
WeekDays wk;

TYPE In_Record_type IS RECORD 
	(COMPANY 	 VARCHAR2(3),
	 EMPL_ID	 VARCHAR2(9),
	 ENTERED_HRS VARCHAR2(6),
	 TIME_SIGN	 INTEGER, 
	 LAB_CST	 VARCHAR2(7),
	 WAGE_SIGN   INTEGER, 
	 REFERENCE	 VARCHAR2(2),
	 PAY_TYPE	 VARCHAR2(3),
	 TS_DT	 VARCHAR2(6),
	 SSN	 	 VARCHAR2(10));

l_InRec In_Record_type;

TYPE Wage_type IS RECORD 
	(LAB_CST	 FLOAT,
	 WAGE_TYPE   VARCHAR(4));

TYPE  Wage_DataType IS TABLE OF Wage_type INDEX BY BINARY_INTEGER;

Wage_Data Wage_DataType;
Wage_Data_Empty Wage_DataType;

l_sSaveEMPL_ID	VARCHAR2(9) := '##';
l_sSaveSSN        VARCHAR2(10);
l_bFirstTime	BOOLEAN := TRUE;
n 			INTEGER;
n1 			INTEGER;
FirstDay 		DATE;

----------------------------------------------------------------------------
FUNCTION OpenFile (p_Dir    IN  VARCHAR2,
                   p_File   IN  VARCHAR2,
                   p_mode   IN  VARCHAR2,
                   p_Handle OUT UTL_FILE.FILE_TYPE) RETURN BOOLEAN IS
    lstrFileName VARCHAR2(200);

    BEGIN
      lstrFileName := '[' || p_Dir || '] [' || p_File || ']';
      p_Handle 	 := UTL_FILE.FOPEN(p_Dir, p_File, p_mode);
      RETURN TRUE;

    EXCEPTION

       WHEN UTL_FILE.INVALID_PATH THEN
            dbms_output.put_line('OpenFile:Invalid Path: '      || lstrFileName);
            RETURN FALSE;
       WHEN UTL_FILE.INVALID_MODE THEN
            dbms_output.put_line('OpenFile:Invalid Mode: '      || lstrFileName);
            RETURN FALSE;
       WHEN UTL_FILE.INVALID_OPERATION THEN
            dbms_output.put_line('OpenFile:Invalid Operation: ' || lstrFileName);
            RETURN FALSE;
       WHEN OTHERS THEN
            dbms_output.put_line('OpenFile:Others Exception: '  || lstrFileName);
            RETURN FALSE;

END OpenFile;

----------------------------------------------------------------------------
FUNCTION ReadRecord (p_Handle IN  UTL_FILE.FILE_TYPE) RETURN BOOLEAN IS
    	p_string VARCHAR2(1000);
BEGIN
      UTL_FILE.GET_LINE(p_Handle, p_string);
										 --  TH1	   	    1   3  not used
	l_InRec.COMPANY 	  := RTRIM(SubStr(p_string, 04, 3)); --  COMPANY	    4   3  alpha/numeric (required)
										 --  99999		    7   5  not used
	l_InRec.EMPL_ID	  := RTRIM(SubStr(p_string, 12, 8)); --  EMPLOYEE_ID     12   8  alpha/numeric (required)
										 --  BLANK		   20   2  not used
										 --  99		   22   2  not used
	l_InRec.ENTERED_HRS := RTRIM(SubStr(p_string, 24, 5)); --  ENTERED_HOURS   24   5  numeric (1 decimal)
										 --  REFERENCE_1     29   1  "P" means negative hours
	l_InRec.LAB_CST	  := RTRIM(SubStr(p_string, 30, 7)); --  LABOR_DOLLARS   30   7  numeric (2 decimal)
										 --  REFERENCE_2     37   2  "%P" means negative dollars
										 --  BLANK		   39   2  not used
	l_InRec.REFERENCE   := RTRIM(SubStr(p_string, 41, 2)); --  REFERENCE  	   41   2  not used
										 --  BLANK		   43   9  not used
	l_InRec.PAY_TYPE	  := RTRIM(SubStr(p_string, 52, 3)); --  PAY_TYPE	   52   3  alpha/numeric (required)
										 --  BLANK		   55   3  not used
	l_InRec.TS_DT	  := RTRIM(SubStr(p_string, 58, 6)); --  TIMESHEET_DATE  58   6  DDMMYY format
										 --  TIMESHEET_TYPE  64   1  not used
	
	l_InRec.TIME_SIGN := 1;
	l_InRec.WAGE_SIGN := 1;

	IF UPPER(SubStr(p_string, 29, 1)) = 'P' THEN
	    l_InRec.TIME_SIGN := -1; 
	END IF;
	IF UPPER(SubStr(p_string, 38, 1)) = 'P' THEN
	    l_InRec.WAGE_SIGN := -1; 
	END IF;

      RETURN TRUE; 	  -- success

EXCEPTION

      WHEN NO_DATA_FOUND THEN
		 RETURN FALSE;
      WHEN UTL_FILE.INVALID_FILEHANDLE THEN
            dbms_output.put_line('ReadRecord: Invalid File Handle');
            RETURN FALSE;
      WHEN UTL_FILE.INVALID_OPERATION THEN
            dbms_output.put_line('ReadRecord: Invalid Operation');
            RETURN FALSE;
      WHEN UTL_FILE.READ_ERROR THEN
            dbms_output.put_line('ReadRecord: Read Error');
            RETURN FALSE;
      WHEN OTHERS THEN
            dbms_output.put_line('ReadRecord: Others Exception');
            RETURN FALSE;

END ReadRecord;

----------------------------------------------------------------------------
PROCEDURE Write_OutFile (p_Handle IN UTL_FILE.FILE_TYPE,
                         p_Data   IN VARCHAR2) IS

BEGIN
	UTL_FILE.PUT_LINE (p_Handle, p_Data);

EXCEPTION
	WHEN UTL_FILE.INVALID_PATH THEN	
		dbms_output.put_line('Error in Write_OutFile INVALID PATH');
		RAISE;
	WHEN UTL_FILE.INVALID_MODE THEN	
		dbms_output.put_line('Error in Write_OutFile INVALID MODE');
		RAISE;
	WHEN UTL_FILE.INVALID_OPERATION THEN	
		dbms_output.put_line('Error in Write_OutFile INVALID OPERATION');
		RAISE;
	WHEN UTL_FILE.WRITE_ERROR THEN	
		dbms_output.put_line('Error in Write_OutFileWrite WRITE ERROR');
		RAISE;
	WHEN UTL_FILE.INTERNAL_ERROR THEN	
		dbms_output.put_line('Error in Write_OutFile INTERNAL ERROR');
		RAISE;
	WHEN UTL_FILE.INVALID_FILEHANDLE THEN	
		dbms_output.put_line('Error in Write_OutFile INVALID_FILEHANDLE');
		RAISE;
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('Error in Write_OutFile:. ' || SQLErrM);
		RAISE;

END Write_OutFile;

----------------------------------------------------------------------------
PROCEDURE Write_EventLog (p_EVENT_INFO IN LCD.EVENT_LOG.EVENT_INFO%TYPE) IS
    	iErr INTEGER;
BEGIN
 	If LCD.shared.f_event_log_set (p_Org, l_PreProcName, 'P', p_EVENT_INFO) = -1 Then
	    l_bError := True;
	    RAISE EventLogError;
	END IF;
EXCEPTION
      WHEN OTHERS THEN
	    DBMS_OUTPUT.PUT_LINE('Error in Write_EventLog:. ' || SQLErrM);
	    RAISE;
END Write_EventLog;

----------------------------------------------------------------------------
FUNCTION ConvertToTimeType (p_PayType  IN VARCHAR2,
			    	    p_TimeType OUT VARCHAR2) RETURN BOOLEAN 
	IS
	CURSOR c_PT
	IS
	SELECT ATT_ABS_TYPE
	FROM LCD.TOE_ATTABS_MAP
	WHERE TOE_CODE = RTRIM(p_PayType) AND
	    	RTRIM(SHIFT_CODE) IS NULL And
		ORG_CODE = p_Org;

	r_PT  c_PT%ROWTYPE;
BEGIN
	p_TimeType := NULL;
 	OPEN c_PT;
	FETCH c_PT INTO r_PT;

	IF c_PT%FOUND THEN
	    p_TimeType := r_PT.ATT_ABS_TYPE;
	    RETURN TRUE; 
	ELSE
	    l_bValidationErr  := True;
	    IF NVL(INSTR(l_IllegalTimeType, p_PayType, 1),0) = 0  THEN
	        l_IllegalTimeType := l_IllegalTimeType || l_commaT || p_PayType;
	        l_commaT := ', ';
 	    END IF;
	    RETURN FALSE;
	END IF;

	CLOSE c_PT;
EXCEPTION
      WHEN OTHERS THEN
	    DBMS_OUTPUT.PUT_LINE ('Error in ConvertToTimeType '  || SQLERRM);
	    RAISE;
END ConvertToTimeType;
 
----------------------------------------------------------------------------
PROCEDURE GetSSN (p_empId   IN LCD.WORKER.WORKER_ID%TYPE, 
			p_orgcode IN LCD.WORKER.ORG_CODE%TYPE)
	IS
	CURSOR c_SSN 
	IS
	SELECT WORKER_SSN
	FROM LCD.WORKER
	WHERE WORKER_ID = RTRIM(p_empId)   AND
	    	ORG_CODE  = RTRIM(p_orgcode);

	r_ssn  c_SSN%ROWTYPE;

	CURSOR c_WT
	IS
	Select NVL(G.WORKER_TYPE, ' ') WORKER_TYPE
	From LCD.WORKER_HIST h, LCD.GROUP_SUBGROUP g
	Where h.worker_id   = RTRIM(p_empId)    And 
		h.ORG_CODE    = RTRIM(p_orgcode)  And 
		h.update_date = ( Select MAX(update_date)
					From LCD.WORKER_HIST  
					Where WORKER_ID = RTRIM(p_empId) And 
						ORG_CODE = RTRIM(p_orgcode)) And
		g.ORG_CODE = RTRIM(p_orgcode) And
		g.WORKER_GROUP = h.EMPLOYEE_GROUP And
		g.WORKER_SUB_GROUP = h.EMPLOYEE_SUB_GROUP;

BEGIN
	IF l_EMPL_curr = RTRIM(p_empId) THEN
	    l_InRec.SSN := l_SSN_curr;
	ELSE
	    l_EMPL_curr := RTRIM(p_empId);
	    l_InRec.SSN := NULL;
	    l_SSN_curr  := NULL;
 	    OPEN c_SSN;
	    FETCH c_SSN INTO r_ssn;

	    IF c_SSN%FOUND THEN
	        l_InRec.SSN := r_ssn.WORKER_SSN;
  		  l_SSN_curr  := r_ssn.WORKER_SSN;
	    ELSE
		  l_bValidationErr := True;

              IF INSTR(l_MissingWorkers, p_empId, 1, 1) = 0  OR l_MissingWorkers IS NULL Then
		      l_WrkrMissing := l_WrkrMissing + 1;
	            IF l_WrkrMissing < 30 THEN	
	                l_MissingWorkers := l_MissingWorkers || l_commaM || p_empId;
			    l_DispCount := l_DispCount + 1;
			    IF l_DispCount > 6 THEN
	                	  l_commaM := ',' || l_linefeed;
				  l_DispCount := 0;
			    ELSE
				  l_commaM := ', '; 
			    END IF;  	
 	            END IF;
		  END IF;
	    END IF;

	    CLOSE c_SSN;
	END IF;

	OPEN c_WT;
	FETCH c_WT INTO l_WorkerType;
	If c_WT%NOTFOUND THEN
		l_WorkerType := ' '; 
	END IF;
	CLOSE c_WT;

EXCEPTION
      WHEN OTHERS THEN
	    CLOSE c_SSN;
	    DBMS_OUTPUT.PUT_LINE ('Error in GetSSN '  || SQLERRM);
	    RAISE;
END GetSSN;


----------------------------------------------------------------------------
PROCEDURE Insert_To_CP_TIME 
	IS
	sLayout 	 VARCHAR2(200);
	n 		 INTEGER := 1;
      l_EnteredHrs FLOAT;
 	l_DailyHrs   FLOAT;
	l_WriteHrs   FLOAT;
BEGIN
	l_EnteredHrs := TO_NUMBER(l_InRec.ENTERED_HRS) / 10;
	l_DailyHrs := (FLOOR((l_EnteredHrs * 10) / 5)) / 10;

	WHILE (n < 6)
	LOOP
	    IF n = 5 THEN
		  l_WriteHrs := l_EnteredHrs;	-- Friday
	    ELSE
		  l_WriteHrs := l_DailyHrs;	-- Monday thru Thursday
	    END IF;

	    IF l_WriteHrs != 0 THEN
		--  sLayout := RPAD(l_InRec.EMPL_ID, 10)  	   	   ||
		--		 RPAD(l_InRec.SSN, 10)  		   ||
		--		 TO_CHAR(WeekDays(n), 'MM/DD/YYYY')    ||
		--		 RPAD(l_TimeType, 4)			   ||
		--  		 TO_CHAR((l_WriteHrs * l_InRec.TIME_SIGN ), '999999.99') ||
	    	--		 RPAD(p_Org, 63);

		--  Write_OutFile (lFileHandleTime, sLayout);

		  INSERT INTO CP_GROSSPAY_TIME
				 (ORG_CODE, WORKER_ID, SSN,
				  WEEK_DATE, TIMETYPE, HOURS)
 			VALUES (p_Org, l_InRec.EMPL_ID, l_InRec.SSN,
				  WeekDays(n), l_TimeType, l_WriteHrs * l_InRec.TIME_SIGN);
	    END IF;

	    l_EnteredHrs := l_EnteredHrs - l_DailyHrs;
          n := n + 1;
    	END LOOP;

	l_TimeCount := l_TimeCount + 5;

EXCEPTION
      WHEN OTHERS THEN
	    DBMS_OUTPUT.PUT_LINE ('Error in Insert_To_CP_TIME '  || SQLERRM);
	    RAISE;
END Insert_To_CP_TIME;

----------------------------------------------------------------------------
PROCEDURE Insert_To_CP_PAY (p_EmpID IN l_InRec.EMPL_ID%TYPE, 
				    p_SSN   IN l_InRec.SSN%TYPE)   
	IS
	sLayout VARCHAR2(200);

BEGIN

	IF NVL(Wage_Data.LAST,0) > 0 THEN
	    FOR i in Wage_Data.FIRST .. Wage_Data.LAST
	        LOOP
		  IF Wage_Data(i).LAB_CST <> 0  THEN
			INSERT INTO CP_GROSSPAY_PAY 
				 (ORG_CODE, WORKER_ID, SSN, 
				  WAGETYPE, LABORCOST)
 			VALUES (p_Org, p_EmpID, p_SSN,
				  Wage_Data(i).WAGE_TYPE, Wage_Data(i).LAB_CST);
		  END IF;
	        END LOOP;
	END IF;

EXCEPTION
      WHEN OTHERS THEN
	    DBMS_OUTPUT.PUT_LINE ('Error in Insert_To_CP_PAY '  || SQLERRM);
	    RAISE;
END Insert_To_CP_PAY;

----------------------------------------------------------------------------
PROCEDURE SaveWageType    
	IS

	CURSOR c_WT(xSHIFT IN LCD.TOE_PAYWAGE_MAP.SHIFT_CODE%type)
	IS
	SELECT PAY_WAGE_TYPE
	FROM LCD.TOE_PAYWAGE_MAP
	WHERE TOE_CODE   = l_InRec.PAY_TYPE  AND
		SHIFT_CODE = xSHIFT  		 AND
		ORG_CODE   = p_Org;

	r_WT  c_WT%ROWTYPE;

	bFound 	   BOOLEAN;
	l_WDT_idx_next INTEGER;

BEGIN

	IF l_InRec.EMPL_ID != l_sSaveEMPL_ID	THEN
	    IF l_bFirstTime	THEN
		  l_bFirstTime := FALSE;
	    ELSE
		 IF NOT l_bValidationErr THEN
			Insert_To_CP_PAY (l_sSaveEMPL_ID, l_sSaveSSN);
		 END IF;
	    END IF;

	    l_sSaveEMPL_ID := l_InRec.EMPL_ID;
	    l_sSaveSSN     := l_InRec.SSN;
	    Wage_Data 	 := Wage_Data_Empty;
	END IF;

 	OPEN c_WT (l_WorkerType);
	FETCH c_WT INTO r_WT;

	IF c_WT%NOTFOUND THEN
	    CLOSE c_WT;
	    OPEN c_WT (' ');
	    FETCH c_WT INTO r_WT;
	END IF;
	
	IF c_WT%FOUND THEN
	    l_WDT_idx_next := 0;
	    bFound := FALSE;

	    IF NVL(Wage_Data.LAST,0) > 0 THEN
		  FOR i IN  Wage_Data.FIRST .. Wage_Data.LAST
			LOOP
			IF Wage_Data(i).WAGE_TYPE = r_WT.PAY_WAGE_TYPE  THEN
			    Wage_Data(i).LAB_CST :=  Wage_Data(i).LAB_CST + (TO_NUMBER(l_InRec.LAB_CST) / 100) * l_InRec.WAGE_SIGN;
			    bFound := TRUE;
			    EXIT;
		      END IF;
			END LOOP;
	    END IF;

	    IF NOT bFound THEN
		  l_WDT_idx_next  := NVL(Wage_Data.LAST,0) + 1;
		  Wage_Data(l_WDT_idx_next).LAB_CST   := (TO_NUMBER(l_InRec.LAB_CST) / 100) * l_InRec.WAGE_SIGN;
		  Wage_Data(l_WDT_idx_next).WAGE_TYPE := r_WT.PAY_WAGE_TYPE;
 	    END IF;
	ELSE
	    l_bValidationErr  := True;
	    IF NVL(INSTR(l_IllegalWageType, l_InRec.PAY_TYPE, 1), 0) = 0  THEN
	        l_IllegalWageType := l_IllegalWageType || l_commaW || l_InRec.PAY_TYPE;
	        l_commaW := ', '; 
	    END IF;
	END IF;

	CLOSE c_WT;

EXCEPTION
      WHEN OTHERS THEN
	    DBMS_OUTPUT.PUT_LINE ('Error in SaveWageType '  || SQLERRM);
	    RAISE;

END SaveWageType;

----------------------------------------------------------------------------
PROCEDURE Write_WAGE_File 
	IS
	CURSOR curWage    IS
		Select ORG_CODE, WORKER_ID, SSN, WAGETYPE, SUM(LABORCOST) TOTLABORCOST
		From CP_GROSSPAY_PAY
		Where ORG_CODE = p_Org
		Group By ORG_CODE, WORKER_ID, SSN, WAGETYPE
		Having  SUM(LABORCOST) != 0 
		Order by WORKER_ID, WAGETYPE;

	sLayout VARCHAR2(200);

BEGIN
   	FOR recWage IN curWage
		LOOP

		sLayout := RPAD(recWage.WORKER_ID, 10)   	 		  ||
			     RPAD(recWage.SSN, 10)  	  	 	 	  ||
			     'A'				  	 	 	  ||
			     TO_CHAR(WeekDays(1), 	   'MM/DD/YYYY')    ||
			     TO_CHAR(l_WeekEndingDate , 'MM/DD/YYYY') 	  ||
			     RPAD(recWage.WAGETYPE, 4)			  ||   
			     TO_CHAR(recWage.TOTLABORCOST, '999999.99')	  || 
		     	     '      0.00'					  	  ||
		     	     '2010' 						  ||
		     	     RPAD(p_Org, 3)					  ||
			     TO_CHAR(l_WeekEndingDate , 'MM/DD/YYYY');

		Write_OutFile (lFileHandleWage, sLayout);
		l_WageCount := l_WageCount + 1;
		l_TotLabCost := l_TotLabCost + recWage.TOTLABORCOST;

		END LOOP; 

EXCEPTION
      WHEN OTHERS THEN
	    DBMS_OUTPUT.PUT_LINE ('Error in Write_WAGE_File '  || SQLERRM);
	    RAISE;
END Write_WAGE_File;

----------------------------------------------------------------------------
PROCEDURE Write_TIME_File
	IS
	CURSOR curTime    IS
		Select ORG_CODE, WORKER_ID, SSN, WEEK_DATE, TIMETYPE, SUM(HOURS) TOTHOURS
		From CP_GROSSPAY_TIME 
		Where ORG_CODE = p_Org
		Group By ORG_CODE, WORKER_ID, SSN, WEEK_DATE, TIMETYPE
		Having  SUM(HOURS) != 0
		Order By WORKER_ID, TIMETYPE, WEEK_DATE;

	sLayout VARCHAR2(200);

BEGIN
   	FOR recTime IN curTime
		LOOP

		sLayout := RPAD(recTime.WORKER_ID, 10)  	   	    ||
			     RPAD(recTime.SSN, 10)  		   	    ||
			     TO_CHAR(recTime.WEEK_DATE, 'MM/DD/YYYY') ||
			     RPAD(recTime.TIMETYPE, 4)		    ||
			     TO_CHAR(recTime.TOTHOURS, '999999.99')   ||
	    		     RPAD(p_Org, 63);

		Write_OutFile (lFileHandleTime, sLayout);
		l_TimeCount := l_TimeCount + 1;
		l_TotHours  := l_TotHours + recTime.TOTHOURS;

    		END LOOP;

EXCEPTION
      WHEN OTHERS THEN
	    DBMS_OUTPUT.PUT_LINE ('Error in Write_TIME_File '  || SQLERRM);
	    RAISE;
END Write_TIME_File;

-- =========================================================================
BEGIN
	UPDATE LCD.JOB_TABLE  
		SET COMMENTS       = 'Preprocessor is running'
		WHERE ORG_CODE     = p_Org  AND  
		      JOB_NAME     = l_PreProcName;

	DELETE FROM CP_GROSSPAY_PAY
		WHERE ORG_CODE     = p_Org; 

	DELETE FROM CP_GROSSPAY_TIME
		WHERE ORG_CODE     = p_Org; 

	COMMIT;

 	Write_EventLog (p_WeekEnding || ' - ' || p_InFileName || ' Started');

	l_WeekEndingDate := TO_DATE(p_WeekEnding, 'YYYYMMDD');

 	IF RTRIM(TO_CHAR(l_WeekEndingDate,'DAY')) = 'SATURDAY'      THEN	-- points to Monday
            FirstDay := l_WeekEndingDate -  5;
	ELSIF RTRIM(TO_CHAR(l_WeekEndingDate,'DAY')) = 'FRIDAY'     THEN	-- points to Monday
            FirstDay := l_WeekEndingDate -  4;
	ELSE
    	      FirstDay := l_WeekEndingDate - 6;	    
	END IF;

	n  := 1;
      n1 := 0;

	WHILE (n < 6)
		LOOP
		    WeekDays(n) := FirstDay  + n1;
                WHILE (RTRIM(TO_CHAR(WeekDays(n),'DAY')) IN ('SATURDAY', 'SUNDAY'))
                    LOOP
                    n1 := n1 + 1;
                    WeekDays(n) := FirstDay  + n1;
                    END LOOP;
		    n1 := n1 + 1;
		    n := n + 1;
 		END LOOP;

	l_dir_name_IN  := CSC_GET.file_location(p_Org) || '\IN';
	l_dir_name_OUT := CSC_GET.file_location(p_Org) || '\OUT';

	IF OpenFile (l_dir_name_IN, p_InFileName, 'R', lFileHandleIn) THEN

            WHILE ReadRecord(lFileHandleIn) And NOT l_bError
			LOOP
				l_InCount := l_InCount + 1;

				GetSSN (l_InRec.EMPL_ID, p_Org); 

		 		IF TO_NUMBER(l_InRec.ENTERED_HRS) != 0	THEN
					IF ConvertToTimeType (l_InRec.PAY_TYPE, l_TimeType) THEN
						IF Not l_bValidationErr Then
							Insert_To_CP_TIME;
						END IF;
					END IF;
				END IF;

		 		IF TO_NUMBER(l_InRec.LAB_CST) != 0	THEN
					SaveWageType;
				END IF;
			END LOOP;

		 	IF NOT l_bValidationErr THEN
				Insert_To_CP_PAY (l_sSaveEMPL_ID, l_sSaveSSN);

				IF OpenFile (l_dir_name_OUT, p_FileNameWage,  'W', lFileHandleWage) THEN
					Write_WAGE_File;
                       		UTL_FILE.FCLOSE (lFileHandleWage);
		 		END IF;

		     		IF OpenFile (l_dir_name_OUT, p_FileNameTime, 'W', lFileHandleTime) THEN
					Write_Time_File;
                       		UTL_FILE.FCLOSE (lFileHandleTime);
				END IF;
			END IF;

           	UTL_FILE.FCLOSE (lFileHandleIn);   
	END IF;

	IF l_bValidationErr Then
	    sStatus := 'F';
	    IF l_IllegalTimeType IS NOT NULL THEN
	        sComments := 'Unable to convert TIME Types: ' || REPLACE(REPLACE(l_IllegalTimeType, ' ', NULL), ',', ', ')  || l_linefeed;
	    END IF;
	    IF l_IllegalWageType IS NOT NULL THEN
	        sComments := sComments || 'Unable to convert WAGE Types: ' || REPLACE(REPLACE(l_IllegalWageType, ' ', NULL), ',', ', ') || l_linefeed;
	    END IF;
	    IF l_WrkrMissing > 0 THEN
	        sComments := sComments || TO_CHAR(l_WrkrMissing) || ' workers not in Worker table'  || l_linefeed ||
                                        '(' || l_MissingWorkers || ')';
	    END IF;
	ELSE
	    sStatus := 'C';
	    sComments := 'Preprocessor successfully ended '        			    || l_linefeed ||
					'Input Records processed: ' || TO_CHAR(l_InCount)   || l_linefeed ||
					'   Time Records written: ' || TO_CHAR(l_TimeCount) || l_linefeed ||
					'            Total Hours: ' || TO_CHAR(l_TotHours)  || l_linefeed ||
					'    Pay Records written: ' || TO_CHAR(l_WageCount) || l_linefeed ||
					'             Total Cost: ' || TO_CHAR(l_TotLabCost);
	END IF;

	INSERT INTO LCD.TRANS_LOG 
 		 (ORG_CODE, TRANS_DATE, TRANS_TYPE, TABLE_NAME, TRANS_USER_ID, BEF_TRANS_DATA)
	VALUES (p_Org, SYSDATE, 'A', 'CP_GP_PREPROC', p_User, sComments);
 
	UPDATE LCD.JOB_TABLE  
	SET JOB_STATUS     = sStatus,
	    DATE_COMPLETED = SYSDATE,
	    COMMENTS       = Substr(sComments, 1, 300)
	WHERE ORG_CODE     = p_Org  AND  
		JOB_NAME     = l_PreProcName;

 	Write_EventLog (p_WeekEnding || ' - ' || p_InFileName || ' Ended');
 
	COMMIT;

	UTL_FILE.FCLOSE_ALL;

	dbms_output.put_line('-- END CP_GP_PREPROC --');

EXCEPTION
                          
      WHEN OTHERS THEN	
		l_ErrMsg := To_Char(SQLCODE) || ' ' || SubStr(SqlErrM, 1, 200);
            DBMS_OUTPUT.PUT_LINE (SqlErrM);
		UPDATE LCD.JOB_TABLE  
		    SET JOB_STATUS = 'F',
	              COMMENTS	 = COMMENTS || l_linefeed || l_ErrMsg
		    WHERE ORG_CODE = p_Org  AND  
		         JOB_NAME	 = l_PreProcName;

-- 		Write_EventLog (p_WeekEnding || ' - ' || p_InFileName || ' Ended Abnormally');');

		COMMIT;
            UTL_FILE.FCLOSE_ALL;

END CP_GP_PREPROC;
/
show errors

