SET SERVEROUT ON SIZE 999999

CREATE OR REPLACE PROCEDURE
	LCD.CP_GP_SUBMIT(p_User         IN  VARCHAR2,
            	     p_Org          IN  VARCHAR2,
            	     p_InFileName   IN  VARCHAR2,
           		     p_WeekEnding   IN  VARCHAR2,
           		     p_FileNamePay  IN  VARCHAR2,
           		     p_FileNameTime IN  VARCHAR2)
IS

	l_JOB_NUM	    INTEGER;
	L_JOB_STRING    VARCHAR2(600);
	l_start         DATE;
	l_interval      VARCHAR2(40);
	l_PreProcName   VARCHAR2(20) := 'CP_GP_PREPROC';

-- ***********************************************************************
-- SUBMIT COSTPOINT GROSS PAY PREPROCESSOR
-- ***********************************************************************
-- Created: 22 Sep 2006
--    DD MMM YYYY xxxxxx
--                xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
--                xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
--
-- ***********************************************************************

BEGIN
	l_start 	 := SYSDATE;
	l_interval   := NULL;  -- set to run once
	l_JOB_STRING := 'LCD.CP_GP_PREPROC' || '(''' || p_User 	   || ''',''' ||  
									p_Org  	   || ''',''' ||   
									p_InFileName   || ''',''' ||  
									p_WeekEnding   || ''',''' ||  
									p_FileNamePay  || ''',''' ||  
									p_FileNameTime || ''');'; 
 

 
	dbms_output.put_line(l_JOB_STRING );



      DBMS_JOB.SUBMIT(l_JOB_NUM, l_JOB_STRING,l_start, l_interval, TRUE);

	UPDATE LCD.JOB_TABLE  
		SET DATE_SUBMITTED = l_start,   
		    JOB_STATUS     = 'A',
		    JOB_NUMBER     = l_JOB_NUM,
	 	    DATE_COMPLETED = NULL,
		    DATE_STARTED   = l_start,
		    JOB_PARAM      = l_JOB_STRING,
	          TABLE_NAME     = l_PreProcName,
	          COMMENTS       = 'Preprocessor Submitted' 
		WHERE ORG_CODE     = p_Org  AND  
		      JOB_NAME     = l_PreProcName;

	IF SQL%ROWCOUNT = 0 THEN

		INSERT INTO LCD.JOB_TABLE (ORG_CODE,
	         	 			   DATE_SUBMITTED,
	         			   	   JOB_STATUS,
	         	 		   	   JOB_NUMBER,
	         	 		   	   DATE_STARTED,
	         	 		   	   JOB_NAME,
	         	 		   	   JOB_PARAM,
	         	 		   	   TABLE_NAME,
	         	 		   	   COMMENTS)
	     			   	 VALUES (p_Org,
					   	   l_start,
					   	   'A',
					   	   l_JOB_NUM,
					   	   l_start,
					   	   l_PreProcName,
					   	   l_JOB_STRING,
					   	   l_PreProcName,
					   	   'Preprocessor Submitted');
	END IF;
	
	COMMIT;

EXCEPTION

      WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE (SQLERRM);
            --p_return := FALSE;

END;
/
show errors
