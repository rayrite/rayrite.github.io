SET SERVEROUT ON SIZE 999999

Declare
        p_User		  VARCHAR2(30)  := 'SSTONE23';
	p_Org     	  VARCHAR2(100) := '200';
	p_InFileName      VARCHAR2(100) := 'RSS PSGrossLabor 09-03-06.txt';
	p_WeekEnding      VARCHAR2(8)   := '20060811';
	p_FileNamePay     VARCHAR2(100) := 'PAY.TXT';
	p_FileNameTime    VARCHAR2(100) := 'TIME.TXT';

Begin
        LCD.CP_GP_SUBMIT(p_User,
            		 p_Org,
            		 p_InFileName,
           		 p_WeekEnding,
           		 p_FileNamePay,
           		 p_FileNameTime);

	DBMS_OUTPUT.PUT_LINE ('end of submission');
End;
