CREATE TABLE CP_GROSSPAY_TIME
(
ORG_CODE                  CHAR(3),
WORKER_ID                 VARCHAR2(10),
SSN                       VARCHAR2(10),
WEEK_DATE                 DATE,
TIMETYPE                  VARCHAR2(4),
HOURS                     NUMBER
);
CREATE TABLE CP_GROSSPAY_PAY
(
ORG_CODE                  CHAR(3),
WORKER_ID                 VARCHAR2(10),
SSN                       VARCHAR2(10),
WAGETYPE                  VARCHAR2(4),
LABORCOST                 NUMBER
);

